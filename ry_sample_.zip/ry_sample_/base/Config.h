﻿#pragma once 

class CConfig
{
public:
	static void loadConf();
};
