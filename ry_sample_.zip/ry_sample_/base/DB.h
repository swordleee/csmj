﻿#pragma once 

class CDB
{
public:
	static void initDB();
};
